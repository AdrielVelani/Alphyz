package br.com.projeto.apialphyz.dto;

public class ReviewDTO {
}
