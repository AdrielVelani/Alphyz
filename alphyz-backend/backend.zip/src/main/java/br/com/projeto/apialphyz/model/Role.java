package br.com.projeto.apialphyz.model;

public class Role {
}
