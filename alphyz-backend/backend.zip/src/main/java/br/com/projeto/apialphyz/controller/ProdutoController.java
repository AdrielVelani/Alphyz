package br.com.projeto.apialphyz.controller;


import br.com.projeto.apialphyz.model.Produto;
import br.com.projeto.apialphyz.model.Usuario;
import br.com.projeto.apialphyz.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/roupas")
public class ProdutoController {

}


