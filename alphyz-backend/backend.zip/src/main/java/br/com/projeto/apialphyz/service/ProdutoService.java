package br.com.projeto.apialphyz.service;

import org.springframework.stereotype.Service;

@Service
public class ProdutoService {
}
