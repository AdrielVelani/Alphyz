package br.com.projeto.apialphyz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiAlphyzApplicationTests {

    @Test
    void contextLoads() {
    }

}
